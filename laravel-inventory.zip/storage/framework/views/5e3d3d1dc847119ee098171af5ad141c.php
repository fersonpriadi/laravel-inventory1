

<?php $__env->startSection('master-history-delete'); ?>
<h3 style="text-align: center;">History Delete</h3>
    <table class="table table-hover" style="margin: 2rem;">
  <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">kode</th>
      <th scope="col">Nama</th>
      <th style="width: 30%;" scope="col">Deskripsi</th>
      <th scope="col">Restore</th>
     
    </tr>
  </thead>
  <tbody>

  <?php
    $i = 1;
  ?>
<?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th><?php echo e($i++); ?></th>
      <td><?php echo e($b -> kode_barang); ?></td>
      <td><?php echo e($b -> nama); ?></td>
      <td><?php echo e($b -> deskripsi); ?></td>
      <td>
          <a href="<?php echo e(route('update-item', ['id' => $b->id])); ?>" 
          class="btn btn-success rounded-circle"
          onclick="return confirm('Apakah anda yakin restore : <?php echo e($b -> kode_barang); ?> ?')"> 
          <i class="fa-solid fa-trash-can-arrow-up"></i></a>
      </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('stock/all-conten', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppasli\htdocs\laravel-inventory\resources\views/master/barang/delete-history.blade.php ENDPATH**/ ?>