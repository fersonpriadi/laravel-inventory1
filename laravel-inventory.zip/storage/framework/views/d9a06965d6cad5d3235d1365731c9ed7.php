

<?php $__env->startSection('konten-master-stok'); ?>

<h4 style="text-align: center; margin-bottom:3rem; background-color:gold; padding:10px; border-radius:10px;">Data Stok Barang</h4>
<div class="button-stok-option" style="display:flex;  justify-content:center; gap:85%; padding:30px;">
<a class="btn btn-primary" style="margin-left : 2rem;" href="<?php echo e(route('form-stock-barang')); ?>"> 
<i class="fa-solid fa-plus"></i>
</a>

<a class="btn btn-warning" style="margin-left : 2rem;" href="<?php echo e(route('stok-keluar')); ?>"> 
<i class="fa-solid fa-minus"></i>
</a>
</div>

<table class="table table-hover" style="margin: 2rem;">
<thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">KODE</th>
      <th scope="col">STOK MASUK</th>
      <th scope="col">STOK KELUAR</th>
      <th scope="col">STOK SISA</th>
      <th scope="col">STOK MINIMAL</th>
      <th scope="col">DIBUAT KAPAN</th>
    </tr>
  </thead>
  <tbody>

  <?php 
  $i = 1;
  ?>

  <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th style="padding-bottom : 3rem;"><?php echo e($i++); ?></th>
      <td><?php echo e($b -> kode); ?></td>
      <td><?php echo e($b -> stok_masuk); ?></td>
      <td><?php echo e($b -> stok_keluar); ?></td>
      <td><?php echo e($b -> stok_sisa); ?></td>
      <td><?php echo e($b -> stok_minimal); ?></td>
      <td><?php echo e($b -> dibuat_kapan); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('stock/all-conten', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppasli\htdocs\laravel-inventory\resources\views/stock/master-stok.blade.php ENDPATH**/ ?>