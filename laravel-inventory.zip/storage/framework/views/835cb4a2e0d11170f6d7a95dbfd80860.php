<nav class="sb-sidenav accordion sb-sidenav-dark" style="background-color: purple;" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Core</div>
                            <a class="nav-link <?php echo e((Request::segment(1) == 'dashboard') ? 'active' : ''); ?>" href="<?php echo e(url('/dashboard')); ?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                            <hr style="color:blue;">
                            <a class="nav-link <?php echo e((Request::segment(1) == 'master') ? 'active' : ''); ?> " href="<?php echo e(url('/master')); ?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-database"></i></div>
                                Master Data
                            </a>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer" style="background-color: blue;">
                        <div class="small">User berhasil login</div>
                        <?php echo e(Auth::user()->name); ?>

                    </div>
                </nav><?php /**PATH C:\xampp\htdocs\laravel-inventory\resources\views/template/navigasi-kiri.blade.php ENDPATH**/ ?>