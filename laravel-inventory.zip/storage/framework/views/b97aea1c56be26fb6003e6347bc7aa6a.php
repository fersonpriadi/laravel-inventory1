

<?php $__env->startSection('master-konten'); ?>


<h3 style="text-align: center; background-color : gold; padding: 5px 0; border-radius:10px; margin-top:13px;">Form tambah</h3>
<form  action="<?php echo e(route('master-barang-simpan')); ?>" method="post"  class="row g-3">
<?php echo csrf_field(); ?>
<div class="mb-3 w-25">
  <label for="for_kode" class="form-label">Kode</label>
  <input type="text" class="form-control" id="for_kode" name="for_kode" value="<?php echo e(old('for_kode')); ?>" placeholder="input kode" autofocus>
  <?php if($errors->has('for_kode')): ?>
      <div class="badge text-bg-danger"><?php echo e($errors->first('for_kode')); ?></div>
  <?php endif; ?>
</div>
<div class="mb-3 w-50">
  <label for="for_nama" class="form-label">Nama</label>
  <input type="text" class="form-control" id="for_nama" name="for_nama" value="<?php echo e(old('for_nama')); ?>" placeholder="input nama">
  <?php if($errors->has('for_nama')): ?>
      <div class="badge text-bg-danger"><?php echo e($errors->first('for_nama')); ?></div>
  <?php endif; ?>
</div>
<div class="mb-3">
  <label for="for_deskripsi" class="form-label">Deskripsi</label>
  <textarea class="form-control" id="for_deskripsi" name="for_deskripsi" rows="3" placeholder="Input Keterangan Barang"><?php echo e(old('for_deskripsi')); ?></textarea>
  <?php if($errors->has('for_deskripsi')): ?>
      <div class="badge text-bg-danger"><?php echo e($errors->first('for_deskripsi')); ?></div>
  <?php endif; ?>
</div>
<button type="submit" class="btn btn-warning" style="width: auto;">
    <i class="fa fa-solid fa-save"><span style="font-family: 'Times New Roman', Times, serif; margin-left : 10px;">Simpan</span></i>
</button>
</form>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('master/all', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppasli\htdocs\laravel-inventory\resources\views/master/barang/form-tambah.blade.php ENDPATH**/ ?>