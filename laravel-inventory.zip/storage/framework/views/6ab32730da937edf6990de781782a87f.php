

<?php $__env->startSection('konten-image'); ?>

<h1>Konten Image</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppasli\htdocs\laravel-inventory\resources\views/konten-dashboard/display-image.blade.php ENDPATH**/ ?>