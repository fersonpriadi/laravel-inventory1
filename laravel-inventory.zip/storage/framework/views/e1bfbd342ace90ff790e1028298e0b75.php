

<?php $__env->startSection('konten-show'); ?>

<h3 style="margin-bottom : 30px;">Show Data Details</h3>
<?php if(isset($barang[0])): ?>
<?php
        $tanggal_dibuat = new DateTime($barang [0]-> dibuat_kapan);
        $dibuat = $tanggal_dibuat->format('D, d M Y');

        $tanggal_diperbarui = new DateTime($barang [0]-> diperbarui_kapan);
        $diperbarui = $tanggal_diperbarui->format('D, d M Y');

?>

<div class="card" style=" box-shadow :  6px 4px 1px grey; width: 50%; text-align:center; justify-content:center;">
  <div class="card-body">
    <h5 class="card-title"><?php echo e($barang[0]-> kode_barang); ?></h5>
    <h6 class="nama"><?php echo e($barang [0]-> nama); ?></h6>
    <h6 class="card-text"><?php echo e($barang[0]-> deskripsi); ?></h6>
    <span class="card-text">Dibuat Kapan : <?php echo e($dibuat); ?> | <?php echo e($barang [0]-> dibuat_nama); ?></span> <br>
    <span class="card-text">Terakhir Diperbarui  : <?php echo e($diperbarui); ?> | <?php echo e($barang [0]-> diperbarui_nama); ?></span> <br>
  </div>
</div>

<?php else: ?>
<h6>tidak ada barang</h6>

<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master/all', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-inventory\resources\views/master/barang/show-data.blade.php ENDPATH**/ ?>