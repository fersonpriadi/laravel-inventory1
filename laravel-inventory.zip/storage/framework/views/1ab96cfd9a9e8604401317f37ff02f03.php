

<?php $__env->startSection('konten'); ?>

<ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link <?php echo e((Request::segment(2) == 'barang') ? 'active' : ''); ?>" href="<?php echo e(route('master-barang')); ?>">Barang</a>
  </li>
  <li class="nav-item">
    <a class="nav-link <?php echo e((Request::segment(2) == 'kategory') ? 'active' : ''); ?>" href="<?php echo e(route('master-kategory')); ?>">Kategori</a>
  </li>
  <li class="nav-item">
    <a class="nav-link <?php echo e((Request::segment(2) == 'gudang') ? 'active' : ''); ?> " href="<?php echo e(route('master-gudang')); ?>">Gudang</a>
  </li>
</ul>
<div class="tab-content">
  <?php echo $__env->yieldContent('master-konten-barang'); ?>
</div>

<div class="tab-content">
  <?php echo $__env->yieldContent('master-konten'); ?>
</div>

<div class="tab-content ">
  <?php echo $__env->yieldContent('master-konten-kategory'); ?>
</div>

<div class="tab-content">
  <?php echo $__env->yieldContent('master-konten-edit-kategory'); ?>
</div>

<div class="tab-content">
  <?php echo $__env->yieldContent('konten-show'); ?>
</div>

<div class="tab-content ">
  <?php echo $__env->yieldContent('konten-show-kategory'); ?>
</div>

<div class="tab-content">
  <?php echo $__env->yieldContent('konten-form-stock'); ?>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('template/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppasli\htdocs\laravel-inventory\resources\views/master/all.blade.php ENDPATH**/ ?>