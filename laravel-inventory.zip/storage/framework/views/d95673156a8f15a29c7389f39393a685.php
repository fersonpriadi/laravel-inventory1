

<?php $__env->startSection('master-konten'); ?>

    Master Gudang

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master/all', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppasli\htdocs\laravel-inventory\resources\views/master/gudang/index.blade.php ENDPATH**/ ?>