

<?php $__env->startSection('konten'); ?>

<div class="tab-content">
  <?php echo $__env->yieldContent('konten-form-stock'); ?>
</div>

<div class="tab-content">
  <?php echo $__env->yieldContent('form-keluar'); ?>
</div>

<div class="tab-content">
  <?php echo $__env->yieldContent('konten-master-stok'); ?>
</div>


<div class="tab-content">
  <?php echo $__env->yieldContent('master-history-delete'); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppasli\htdocs\laravel-inventory\resources\views/stock/all-conten.blade.php ENDPATH**/ ?>