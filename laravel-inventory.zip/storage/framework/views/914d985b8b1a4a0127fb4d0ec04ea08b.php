<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Inventory</title>
        <link rel="stylesheet" href="<?php echo e(asset('Bootstrap/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('styles.css')); ?>">
        <link rel="shortcut icon" href="<?php echo e(('image/logo1.png')); ?>" type="image/x-icon">
        <link rel="stylesheet" href="<?php echo e(asset('fontawesome-web/css/all.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('fontawesome-web/js/all.min.js')); ?>">
        <script src="<?php echo e(asset('Bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>  
        <script src="<?php echo e(asset('scripts.js')); ?>"></script>  
    </head>
    <body class="sb-nav-fixed">
        <?php echo $__env->make('template/navigasi-atas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
            <?php echo $__env->make('template/navigasi-kiri', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div id="layoutSidenav_content">
                <main">
                    <div class="container-fluid px-4 pt-4">
                        <?php echo $__env->make('template/flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->yieldContent('konten'); ?>
                    </div>
                </main>
               
            </div>
           
        </div>
        <div>
        <?php echo $__env->make('template/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel-inventory\resources\views/template/index.blade.php ENDPATH**/ ?>