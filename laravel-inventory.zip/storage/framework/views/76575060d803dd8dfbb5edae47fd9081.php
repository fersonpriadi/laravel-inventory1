

<?php $__env->startSection('konten-form-stock'); ?>
<h3>Stock Masuk</h3>
<form class="row g-3" action="" method="">
  <div class="col-auto">
  <div class="dropdown">
  <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton2" data-bs-toggle="dropdown">
    Pilih Barang
  </button>
  <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="dropdownMenuButton2">
    <li><a class="dropdown-item" href="#"><?php echo e($b -> kode_barang); ?></a></li>
    <li><a class="dropdown-item" href="#">Another action</a></li>
    <li><a class="dropdown-item" href="#">Something else here</a></li>
    <li><a class="dropdown-item" href="#">Separated link</a></li>
  </ul>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
  </div>
  <div class="col-auto">
    <label for="inputPassword2" class="visually-hidden">Jumlah</label>
    <input type="text" class="form-control" id="inputPassword2" placeholder="Input Jumlah">
  </div>
  <div class="col-auto">
    <button type="submit" class="btn btn-primary mb-3">Simpan</button>
  </div>
</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master/all', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppasli\htdocs\laravel-inventory\resources\views/master_stock/form-stock.blade.php ENDPATH**/ ?>