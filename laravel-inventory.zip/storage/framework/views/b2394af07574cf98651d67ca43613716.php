

<?php $__env->startSection('master-konten-barang'); ?>


<div class="row" style="margin-top : 6px;">
  <div class="col-12 text-end">
    <a href="<?php echo e(route('master-barang-tambah')); ?>">
    <i class="fa fa-solid fa-plus btn btn-primary"></i>
    </a>
  </div>
</div>
    <table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">kode</th>
      <th scope="col">Nama</th>
      <th style="width: 30%;" scope="col">Deskripsi</th>
      <th scope="col">Choice</th>
     
    </tr>
  </thead>
  <tbody>

  <?php
    $i = 1;
  ?>
<?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th><?php echo e($i++); ?></th>
      <td><?php echo e($b -> kode_barang); ?></td>
      <td><?php echo e($b -> nama); ?></td>
      <td><?php echo e($b -> deskripsi); ?></td>
      <td>
          <a href="<?php echo e(route('master-barang-hapus', ['id' => $b->id])); ?>" 
          class="btn btn-danger rounded-circle"
          onclick="return confirm('Apakah anda yakin ingin menghapus : <?php echo e($b -> kode); ?> ?')"> 
          <i class="fa-solid fa-trash"></i></a>

          <a href="<?php echo e(route('master-barang-detail', ['id' => $b->id])); ?>" 
          class="btn btn-success rounded-circle"> 
          <i class="fa-solid fa-eye"></i></a>

          <a href="<?php echo e(route('master-barang-edit', ['id' => $b->id])); ?>" 
          class="btn btn-warning rounded-circle"> 
          <i class="fa-solid fa-pencil"></i></a>
      </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master/all', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppasli\htdocs\laravel-inventory\resources\views/master/barang/index.blade.php ENDPATH**/ ?>