

<?php $__env->startSection('master-konten-kategory'); ?>

<div class="row" style="margin-top: 6px;">
  <div class="col-12 text-end">
    <a href="<?php echo e(route('master-kategory-tambah')); ?>">
    <i class="fa fa-solid fa-plus btn btn-primary"></i>
    </a>
  </div>
</div>
    <table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">kode barang</th>
      <th scope="col">kode kategory</th>
      <th scope="col">Jenis Barang</th>
      <th style="width: 30%;" scope="col">Kemasan Barang</th>
      <th scope="col">Choice</th>
     
    </tr>
  </thead>
  <tbody>

  <?php
    $i = 1;
  ?>
<?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>      
      <th><?php echo e($i++); ?></th>
      <th><?php echo e($b -> kode_barang); ?></th>
      <td><?php echo e($b -> kode); ?></td>
      <td><?php echo e($b -> jenis_barang); ?></td>
      <td><?php echo e($b -> kemasang_barang); ?></td>
      <td>
          <a href="<?php echo e(route('master-kategory-hapus', ['id' => $b->id])); ?>" 
          class="btn btn-danger rounded-circle"
          onclick="return confirm('Apakah anda yakin ingin menghapus : <?php echo e($b -> kode); ?> ?')"> 
          <i class="fa-solid fa-trash"></i></a>

          <a href="<?php echo e(route('master-kategory-detail', ['id' => $b->id])); ?>" 
          class="btn btn-success rounded-circle"> 
          <i class="fa-solid fa-eye"></i></a>

          <a href="<?php echo e(route('master-kategory-edit', ['id' => $b->id])); ?>" 
          class="btn btn-warning rounded-circle"> 
          <i class="fa-solid fa-pencil"></i></a>
      </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master/all', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppasli\htdocs\laravel-inventory\resources\views/master/kategory/index.blade.php ENDPATH**/ ?>