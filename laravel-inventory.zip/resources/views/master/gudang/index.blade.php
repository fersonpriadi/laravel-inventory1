@extends('master/all')

@section('master-konten')

    Master Gudang

@endsection